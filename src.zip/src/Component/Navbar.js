import './App.css';

function Navbar() {
  return (
    <div className="navbar">
      <a href="/">මුල් පිටුව</a>
      <a href="/events">සාමාරම්භක ක්‍රියාකාරකම්</a>
      <a href="/donate">දානයන්</a>
      <a href="/contact">සම්බන්ධ වන්න</a>
    </div>
  );
}

export default Navbar;